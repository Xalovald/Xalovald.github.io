package com.example.gsb_visites;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface GsbServices {
    @GET("visiteurs")
    Call<Visiteurs> getAllVisiteurs();
    @POST("login_check")
    Call<Token> getToken(@Body Visiteur visiteur);
}
