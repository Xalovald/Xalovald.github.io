<?php

namespace App\Entity;

use App\Repository\RecipeRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=RecipeRepository::class)
 */
class Recipe
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $title;

    /**
     * @ORM\Column(type="string", length=5000, nullable=true)
     */
    private $extraInfo;

    /**
     * @ORM\Column(type="string", length=5000, nullable=true)
     */
    private $adjustements;

    /**
     * @ORM\ManyToOne(targetEntity=CourseType::class, inversedBy="recipes")
     * @ORM\JoinColumn(nullable=false)
     */
    private $coursetype;

    /**
     * @ORM\OneToMany(targetEntity=Evaluation::class, mappedBy="recipe")
     */
    private $evaluation;

    /**
     * @ORM\ManyToMany(targetEntity=Ingredient::class, mappedBy="recipe")
     */
    private $ingredients;

    /**
     * @ORM\OneToMany(targetEntity=CookingHistory::class, mappedBy="recipes", orphanRemoval=true)
     */
    private $cookingHistories;

    /**
     * @ORM\ManyToOne(targetEntity=Source::class, inversedBy="recipes")
     */
    private $source;

    public function __construct()
    {
        $this->evaluation = new ArrayCollection();
        $this->ingredients = new ArrayCollection();
        $this->cookingHistories = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTitle(): ?string
    {
        return $this->title;
    }

    public function setTitle(string $title): self
    {
        $this->title = $title;

        return $this;
    }

    public function getExtraInfo(): ?string
    {
        return $this->extraInfo;
    }

    public function setExtraInfo(?string $extraInfo): self
    {
        $this->extraInfo = $extraInfo;

        return $this;
    }

    public function getAdjustements(): ?string
    {
        return $this->adjustements;
    }

    public function setAdjustements(?string $adjustements): self
    {
        $this->adjustements = $adjustements;

        return $this;
    }

    public function getCoursetype(): ?CourseType
    {
        return $this->coursetype;
    }

    public function setCoursetype(?CourseType $coursetype): self
    {
        $this->coursetype = $coursetype;

        return $this;
    }

    /**
     * @return Collection|evaluation[]
     */
    public function getEvaluation(): Collection
    {
        return $this->evaluation;
    }

    public function addEvaluation(evaluation $evaluation): self
    {
        if (!$this->evaluation->contains($evaluation)) {
            $this->evaluation[] = $evaluation;
            $evaluation->setRecipe($this);
        }

        return $this;
    }

    public function removeEvaluation(evaluation $evaluation): self
    {
        if ($this->evaluation->removeElement($evaluation)) {
            // set the owning side to null (unless already changed)
            if ($evaluation->getRecipe() === $this) {
                $evaluation->setRecipe(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection|Ingredient[]
     */
    public function getIngredients(): Collection
    {
        return $this->ingredients;
    }

    public function addIngredient(Ingredient $ingredient): self
    {
        if (!$this->ingredients->contains($ingredient)) {
            $this->ingredients[] = $ingredient;
            $ingredient->addRecipe($this);
        }

        return $this;
    }

    public function removeIngredient(Ingredient $ingredient): self
    {
        if ($this->ingredients->removeElement($ingredient)) {
            $ingredient->removeRecipe($this);
        }

        return $this;
    }

    /**
     * @return Collection|CookingHistory[]
     */
    public function getCookingHistories(): Collection
    {
        return $this->cookingHistories;
    }

    public function addCookingHistory(CookingHistory $cookingHistory): self
    {
        if (!$this->cookingHistories->contains($cookingHistory)) {
            $this->cookingHistories[] = $cookingHistory;
            $cookingHistory->setRecipes($this);
        }

        return $this;
    }

    public function removeCookingHistory(CookingHistory $cookingHistory): self
    {
        if ($this->cookingHistories->removeElement($cookingHistory)) {
            // set the owning side to null (unless already changed)
            if ($cookingHistory->getRecipes() === $this) {
                $cookingHistory->setRecipes(null);
            }
        }

        return $this;
    }

    public function getSource(): ?Source
    {
        return $this->source;
    }

    public function setSource(?Source $source): self
    {
        $this->source = $source;

        return $this;
    }
}
