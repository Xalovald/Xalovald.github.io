<?php

namespace App\Entity;

use App\Repository\CookingHistoryRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=CookingHistoryRepository::class)
 */
class CookingHistory
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="datetime")
     */
    private $date;

    /**
     * @ORM\ManyToOne(targetEntity=Recipe::class, inversedBy="cookingHistories")
     * @ORM\JoinColumn(nullable=false)
     */
    private $recipes;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDate(): ?\DateTimeInterface
    {
        return $this->date;
    }

    public function setDate(\DateTimeInterface $date): self
    {
        $this->date = $date;

        return $this;
    }

    public function getRecipes(): ?recipe
    {
        return $this->recipes;
    }

    public function setRecipes(?recipe $recipes): self
    {
        $this->recipes = $recipes;

        return $this;
    }
}
