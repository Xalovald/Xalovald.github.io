<?php

namespace App\Controller;

use App\Entity\CookingHistory;
use App\Form\CookingHistoryType;
use App\Repository\CookingHistoryRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/cooking_history")
 */
class CookingHistoryController extends AbstractController
{
    /**
     * @Route("/", name="cooking_history_index", methods={"GET"})
     */
    public function index(CookingHistoryRepository $cookingHistoryRepository): Response
    {
        return $this->render('cooking_history/index.html.twig', [
            'cooking_histories' => $cookingHistoryRepository->findAll(),
        ]);
    }

    /**
     * @Route("/new", name="cooking_history_new", methods={"GET", "POST"})
     */
    public function new(Request $request, EntityManagerInterface $entityManager): Response
    {
        $cookingHistory = new CookingHistory();
        $form = $this->createForm(CookingHistoryType::class, $cookingHistory);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->persist($cookingHistory);
            $entityManager->flush();

            return $this->redirectToRoute('cooking_history_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->renderForm('cooking_history/new.html.twig', [
            'cooking_history' => $cookingHistory,
            'form' => $form,
        ]);
    }

    /**
     * @Route("/{id}", name="cooking_history_show", methods={"GET"})
     */
    public function show(CookingHistory $cookingHistory): Response
    {
        return $this->render('cooking_history/show.html.twig', [
            'cooking_history' => $cookingHistory,
        ]);
    }

    /**
     * @Route("/{id}/edit", name="cooking_history_edit", methods={"GET", "POST"})
     */
    public function edit(Request $request, CookingHistory $cookingHistory, EntityManagerInterface $entityManager): Response
    {
        $form = $this->createForm(CookingHistoryType::class, $cookingHistory);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->flush();

            return $this->redirectToRoute('cooking_history_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->renderForm('cooking_history/edit.html.twig', [
            'cooking_history' => $cookingHistory,
            'form' => $form,
        ]);
    }

    /**
     * @Route("/{id}", name="cooking_history_delete", methods={"POST"})
     */
    public function delete(Request $request, CookingHistory $cookingHistory, EntityManagerInterface $entityManager): Response
    {
        if ($this->isCsrfTokenValid('delete'.$cookingHistory->getId(), $request->request->get('_token'))) {
            $entityManager->remove($cookingHistory);
            $entityManager->flush();
        }

        return $this->redirectToRoute('cooking_history_index', [], Response::HTTP_SEE_OTHER);
    }
}
