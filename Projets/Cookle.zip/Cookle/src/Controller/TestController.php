<?php

namespace App\Controller;

use App\Entity\Source;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
class TestController extends AbstractController
{
    /**
     * @Route("/test", name="test")
     */

    public function index(): Response
    {
        $leTest = new Source();
        //$leTest->setName("Alexandre");
        $leTest->setName("TestController");
        $leTest->setUrl("https://equilibre.lycee-faure.fr");
        return $this->render('test/index.html.twig', [
            'unTest' => $leTest->getName(),
        ]);

    }

}
