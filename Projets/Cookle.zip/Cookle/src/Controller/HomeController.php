<?php

namespace App\Controller;

use App\Entity\Recipe;
use App\Repository\RecipeRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class HomeController extends AbstractController
{
    /**
     * @Route("/home", name="home")
     */
    public function index(RecipeRepository $recipeRepository): Response
    {

        $recipes = $recipeRepository->findAll();
        $numberRecipe = array_rand($recipes, 1);
        $recipe = $recipes[$numberRecipe];
        unset($recipes[$numberRecipe]);

        return $this->render('home/index.html.twig', [
            'controller_name' => 'HomeController',
            'recipe' => $recipe,
            'recipe_list' => $recipes
        ]);
    }
}
