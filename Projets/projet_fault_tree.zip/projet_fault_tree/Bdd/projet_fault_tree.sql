-- phpMyAdmin SQL Dump
-- version 4.5.4.1
-- http://www.phpmyadmin.net
--
-- Client :  localhost
-- Généré le :  Mar 25 Janvier 2022 à 21:22
-- Version du serveur :  5.7.11
-- Version de PHP :  5.6.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `projet_fault_tree`
--

-- --------------------------------------------------------

--
-- Structure de la table `fault`
--

CREATE TABLE `fault` (
  `id` int(11) NOT NULL,
  `Libelle` text NOT NULL,
  `debut` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `fault`
--

INSERT INTO `fault` (`id`, `Libelle`, `debut`) VALUES
(1, 'Ma souris ne marche plus', 1),
(2, 'Mon écran marche plus', 2);

-- --------------------------------------------------------

--
-- Structure de la table `id_repertoire`
--

CREATE TABLE `id_repertoire` (
  `id_rep` int(11) NOT NULL,
  `id` int(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `id_repertoire`
--

INSERT INTO `id_repertoire` (`id_rep`, `id`) VALUES
(11123, 1),
(11123, 2);

-- --------------------------------------------------------

--
-- Structure de la table `info`
--

CREATE TABLE `info` (
  `date` datetime NOT NULL,
  `nom_pc` varchar(30) CHARACTER SET utf8 NOT NULL,
  `version_pc` varchar(100) CHARACTER SET utf8 NOT NULL,
  `path` varchar(60) CHARACTER SET utf8 NOT NULL,
  `id` int(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `info`
--

INSERT INTO `info` (`date`, `nom_pc`, `version_pc`, `path`, `id`) VALUES
('2022-01-23 20:35:20', 'DESKTOP-U7O1J01', 'build 9200 (Windows 8 Home Premium Edition)', '11123', 1),
('2022-01-24 21:20:24', 'DESKTOP-U7O1J01', 'build 9200 (Windows 8 Home Premium Edition)', '11123', 2);

-- --------------------------------------------------------

--
-- Structure de la table `questions`
--

CREATE TABLE `questions` (
  `id_q` int(11) NOT NULL,
  `id_pb` int(11) NOT NULL,
  `Libelle` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `questions`
--

INSERT INTO `questions` (`id_q`, `id_pb`, `Libelle`) VALUES
(1, 1, 'La lumiere rouge est elle allumée sous la souris ?'),
(2, 1, 'débrancher et rebrancher la souris'),
(3, 1, 'le câble est bien branché ?'),
(4, 2, 'La lumière orange est-elle allumé sous l\'écran');

-- --------------------------------------------------------

--
-- Structure de la table `reponses`
--

CREATE TABLE `reponses` (
  `id_r` int(11) NOT NULL,
  `id_q` int(11) NOT NULL,
  `id_q_suiv` int(11) NOT NULL,
  `id_fin` int(11) DEFAULT NULL,
  `libelle` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `reponses`
--

INSERT INTO `reponses` (`id_r`, `id_q`, `id_q_suiv`, `id_fin`, `libelle`) VALUES
(1, 1, 2, 0, 'oui'),
(2, 1, 3, 0, 'non'),
(3, 2, 4, 1, 'ça fonctionne ?'),
(4, 2, 5, 1, 'ça ne fonctionne pas ?'),
(5, 3, 2, 0, 'Oui');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `fault`
--
ALTER TABLE `fault`
  ADD UNIQUE KEY `id` (`id`);

--
-- Index pour la table `id_repertoire`
--
ALTER TABLE `id_repertoire`
  ADD KEY `INDEX` (`id`);

--
-- Index pour la table `info`
--
ALTER TABLE `info`
  ADD KEY `INDEX` (`id`);

--
-- Index pour la table `questions`
--
ALTER TABLE `questions`
  ADD UNIQUE KEY `id` (`id_q`);

--
-- Index pour la table `reponses`
--
ALTER TABLE `reponses`
  ADD UNIQUE KEY `id` (`id_r`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `fault`
--
ALTER TABLE `fault`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT pour la table `id_repertoire`
--
ALTER TABLE `id_repertoire`
  MODIFY `id` int(60) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `info`
--
ALTER TABLE `info`
  MODIFY `id` int(60) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `questions`
--
ALTER TABLE `questions`
  MODIFY `id_q` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT pour la table `reponses`
--
ALTER TABLE `reponses`
  MODIFY `id_r` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
