<html>
<head>
<link rel="stylesheet" href="./css/style.css" type="text/css">
<title>Fault Tree</title>
<meta charset="utf-8">
</head>
<body>
<?php //début du php / fin du html

require 'Connect.php';

$fault = $bdd->query('SELECT * FROM fault'); //selection de la table fault

$id_rep = $_GET['id_rep'];

$questions = $bdd->query("SELECT * FROM questions
INNER JOIN fault ON questions.id_pb = fault.id
WHERE fault.id = questions.id_pb;");

$reponses=$bdd->query("SELECT * FROM reponses
WHERE id_q=".$_GET['id_q']);
//cette requête sql affiche les réponse qui ont un id_q identique à celui renvoyé par la methode $_GET

$questions_suivante=$bdd->query("SELECT * FROM reponses
INNER JOIN questions ON reponses.id_q_suiv = questions.id_q
WHERE reponses.id_q_suiv = questions.id_q");
?> <!-- fin du php/ début du html -->
<p class="text"><?php echo $_GET['libelle']; ?></p>
<?php //début du php / fin du html

//Cette requête récupère le libelle de la question précédente
while($resultatrep = $reponses->fetch())
{
if($resultatrep['id_fin'] != 1)
{
?> <!-- fin du php/ début du html -->
	<a href="<?php echo "Question_FT.php?id_q_suiv=".$resultatrep['id_q_suiv']."&libelle=".$resultatrep['libelle']."&id_fin=".$resultatrep['id_fin']."&id_rep=".$id_rep."".$resultatrep['id_r']; ?>" class="button button1"><?php echo $resultatrep['libelle']; ?></a></br>
<?php //début du php / fin du html
}
else{
?> <!-- fin du php/ début du html -->
	<a href="<?php echo "Question_FT.php?id_q_suiv=".$resultatrep['id_q_suiv']."&libelle=".$resultatrep['libelle']."&id_fin=".$resultatrep['id_fin']."&id_rep=".$id_rep."".$resultatrep['id_r']."&confirm=1"; ?>" class="button button1"><?php echo $resultatrep['libelle']; ?></a></br>
	<!--ça fonctionne est ici ou fin de boucle-->

<?php //début du php / fin du html
}
//cette requête affiche des boutons en fonction de l'id_q qu'elle reçoit dans la page précédente
}
?> <!-- fin du php/ début du html -->
<div class="centre">
	<form>
		<input type = "button" value = "Vous vous êtes trompé ?"  onclick = "history.back()" class="button button2">
	</form>
</div>
</body>
<html>
