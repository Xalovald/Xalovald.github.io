<html>
<head>
<link rel="stylesheet" href="./css/style.css" type="text/css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script> <!-- Ne pas mettre à jour pour que ça marche bien, liaison bootstrap avec javascript -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"> <!-- cette ligne sert pour avoir une belle mise en page -->
</head>
<body>
<?php
require 'Connect.php'; //ligne pour se connecter à la base de données MySQL

date_default_timezone_set("Europe/Paris");

$i=0;
$path = $_GET['path'];
$verif = false;

//Boucle qui récupère les différents id et les associent à leur tables réspéctive pour effectuer un envoie des
//variables via le formulaire

while($i<strlen($path)){
  $chiffre = substr($path,$i,1);
  //Table fault
  if($i == 0)
  {
    $verif = false;
    $table = 'fault';
    $id = 'id';
  }
	//Table reponses
  elseif($i%2 == 0)
  {
    $verif = true;
    $table = 'reponses';
    $id = 'id_r';
  }
  //Table questions
  else
  {
    $verif = false;
	  $table = 'questions';
	  $id = 'id_q';
  }
	$sql = $bdd->query('SELECT * FROM '.$table.' WHERE '.$id.'='.$chiffre);
	${"row".$i} = $sql->fetch();
  if($verif == true){
    ${'array'.$table}[]=${"row".$i}['libelle'];
  }
  else{
    ${'array'.$table}[]=${"row".$i}['Libelle'];
  }
  $i++;
}

$lbl0 = $row0['Libelle'];

$date = date('Y-m-d H:i:s');
$nom_pc = gethostname();
$version_pc = php_uname("v");
$serializeReponses = implode(",",$arrayreponses);
$serializeQuestions = implode(",",$arrayquestions);
//form pour envoyer le nom, le prénom et l'adresse mail et la capture d'écran devant contenir la panne
//de l'utilisateur la rencontrant
?>
<FORM method="POST" action="envoie.php?serializeReponses=<?php echo $serializeReponses ?>&serializeQuestions=<?php echo $serializeQuestions ?>">
<h1 class="centre">Formulaire de résolution d'erreur</h1>
<?php
echo "<input type='hidden' name='lblFault' value='".$lbl0."'></input></br>";
echo "<input type='hidden' name='Date' value='".$date."'></input></br>";
echo "<input type='hidden' name='nom_pc' value='".$nom_pc."'></input></br>";
echo "<input type='hidden' name='version_pc' value='".$version_pc."'></input></br>";

echo "<input type='text' placeholder='Nom' name='txtNom' required='required'></input></br>";
echo "<input type='text' placeholder='Pr&eacute;nom' name='txtPrenom' required='required'></input></br>";
echo "<input type='text' placeholder='Adresse mail' name='txtmail' required='required'></input></br>";
echo '<p class="commentaire">Prenez une capture d\'écran (utiliser l\'outil capture d\'écran ou bien le reccourci clavier impr. écran syst.) et insérer la dans le bouton</p>';
?>
<form action="upload.php" method="post" enctype="multipart/form-data">
    <label>Select Image File:</label>
    <input type="file" name="image">
    <input type='submit' class='btn'></input>
</form>
<?php


?>
</form>
</body>
</html>
