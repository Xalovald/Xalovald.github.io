<html>
<head>
<link rel="stylesheet" href="./css/style.css" type="text/css">
<meta charset="utf-8">
</head>
<body>
<?php
//Page pour gérer les modifications des champs de la table questions

echo "<form action='update.php?questions_id=".$_GET['questions_id']."' method='POST'>";
echo "<input type='int' name='questions_id_pb' placeholder='id_pb'></input></br>";
echo "<input type='text' name='questions_libelle' placeholder='Libelle'></input></br>";
echo "<input type='submit'></input>";
echo "</form>";
?>
<input type = "button" value = "Vous vous êtes trompé ?"  onclick = "history.back()" class="button button2">
</body>
</html>
