<html>
<head>
<link rel="stylesheet" href="./css/style.css" type="text/css">
<title>Fault Tree</title>
<meta charset="utf-8">
</head>
<body>
<?php //début du PHP / fin du html
date_default_timezone_set("Europe/Paris");
require 'Connect.php';

$fault = $bdd->query('SELECT * FROM fault');
if(isset($_GET['id_rep'])){
	$id_rep = $_GET['id_rep'];
}
if(isset($_GET['confirm'])){
	$date = date('Y-m-d H:i:s');
	$nom_pc = gethostname();
	$version_pc = php_uname("v");
	$bdd->query("INSERT INTO id_repertoire(`id_rep`) VALUES(".$id_rep.")");
	$bdd->query("INSERT INTO info(`date`,`nom_pc`,`version_pc`,`path`) VALUES('".$date."','".$nom_pc."','".$version_pc."','".$id_rep."')");
}

$questions = $bdd->query("SELECT * FROM questions
INNER JOIN fault ON questions.id_pb = fault.id
WHERE fault.id = questions.id_pb;");

$reponses = $bdd->query("SELECT * FROM reponses
INNER JOIN questions ON reponses.id_q = questions.id_q
WHERE reponses.id_q = questions.id_pb;");

$questions_suivante=$bdd->query("SELECT * FROM fault
INNER JOIN questions ON fault.id = questions.id_pb
WHERE fault.id = questions.id_pb");

?> <!-- fin du php/ début du html -->
<h1 class="text centre red">Avant toutes opérations veuillez redémarrez l'ordinateur</h1>
<p class="text centre">Bonjour et bienvenue dans ce questionnaire servant à vous orienter plus simplement vers la résolution de votre problème. </br>
		Pour que vous puissiez soit le résoudre seul(e) pour les problème minimes ou bien que vous puissiez plus simplement orienter </br>
		le technicien qui vous prendra en charge</p>


<?php //début du PHP / fin du html
$id_q_suiv = 0;//Varrible d'initialisation pour savoir si la question affiché est la dernière ou pas
while($resultatfault = $fault->fetch()){
//Cette boucle affiche les boutons suivant la table ou il doit aller les chercher
?> <!-- fin du php/ début du html -->
	<a href="<?php echo "Question_FT.php?libelle=".$resultatfault['Libelle']."&id=".$resultatfault['id']."&id_q_suiv=".$id_q_suiv."&id_rep=".$resultatfault['id']; ?>" class="button button1"><?php echo $resultatfault['Libelle']; ?></a></br>
<?php //début du PHP / fin du html
//Cette requête affiche des boutons pour chaque énoncé dans la table fault et renvoie dans l'url des informations contenu dans
//resultatfault (libelle, id)
}
?> <!-- fin du php/ début du html -->
</body>
</html>
