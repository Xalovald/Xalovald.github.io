<?php //début du php / fin du html
require 'Connect.php';
//Page effectuant la création de variable dans la table fault à partir des modification apporté dans les textBoxs
//de interface_pro_FT.php

if(!empty($_POST['fault_lbl']) && !empty($_POST['fault_debut'])){
$fault_lbl = $_POST['fault_lbl'];
$fault_debut = $_POST['fault_debut'];

$bdd->query("INSERT INTO fault(`Libelle`, `debut`) VALUES('".$fault_lbl."', ".$fault_debut.")");
}

else{
    echo " Impossible de cr&eacute;er ce problème car vous n'avez rempli tous les champs demandés";
	echo "<br>Veuillez remplir tous les champs avant d'insérer des informations<br>";
    echo '<button type="button" class="btn btn-primary" onclick="javascript:history.go(-1)">Retour</button>';
    exit();
}

header('Location: Interface_pro_FT.php');

echo 'enregistrement effectué';
?> <!-- fin du php/ début du html -->
