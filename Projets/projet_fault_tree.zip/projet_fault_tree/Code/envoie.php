
<?php
require 'Connect.php'; //ligne pour se connecter à la base de données MySQL

$txtNom = $_POST['txtNom'];
$txtPrenom = $_POST['txtPrenom'];
$txtmail = $_POST['txtmail'];
$image = $_POST['image'];
$lblFault = $_POST["lblFault"];
$arrayReponses = explode(",",$_GET['serializeReponses']);
$arrayQuestions = explode(",",$_GET['serializeQuestions']);
$date = $_POST["Date"];
$nom_pc = $_POST["nom_pc"];
$version_pc = $_POST["version_pc"];
$msg = "Nom: $txtNom\n";
$msg .= "Prenom: $txtPrenom\n";
$msg .= "E-Mail: $txtmail\n";
$msg .= "Problème: $lblFault\n";
$msg .= "Questions:\n";

for($i=0;$i<count($arrayQuestions);$i++){
    $msg .=$arrayQuestions[$i]."\n";
}
$msg .= "Reponses: \n";
for($i=0;$i<count($arrayReponses);$i++){
    $msg .=$arrayReponses[$i]."\n";
}
$msg .= "Date: $date\n";
$msg .= "Nom de l'ordinateur: $nom_pc\n";
$msg .= "Version du système d'exploitation: $version_pc\n";
$msg .= "Image:\t$image\n\n";
//Pourait continuer ainsi jusqu'à la fin du formulaire

$destinataire = "gbahno@ch-annecygenevois.fr";
$subject = "Formulaire Fault tree";

$mailheaders = "From: gbahno@ch-annecygenevois.fr";

mail($destinataire, $subject, $msg, $mailheaders);

echo "<HTML><HEAD>";
echo "<TITLE>Formulaire envoyer!</TITLE></HEAD><BODY>";
echo "<H1 align=center>Merci, $txtPrenom $txtNom</H1>";
echo "<P align=center>";
echo "Votre formulaire à bien été envoyé !</P>";
echo "</BODY></HTML>";

?>
