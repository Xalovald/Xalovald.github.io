<html>
<head>
<link rel="stylesheet" href="./css/style.css" type="text/css">
<title>Fault Tree</title>
<meta charset="utf-8">
</head>
<body>
<?php //début du php / fin du html
require 'Connect.php';

$fault = $bdd->query('SELECT * FROM fault
INNER JOIN questions ON fault.id = questions.id_pb
WHERE fault.id = questions.id_pb');

$id_rep = $_GET['id_rep'];

$reponses = $bdd->query("SELECT * FROM reponses
INNER JOIN questions ON reponses.id_q = questions.id_pb
WHERE reponses.id_q = questions.id_pb;");
?> <!-- fin du php/ début du html -->
<p class="text"><?php echo $_GET['libelle']; ?></p>
<?php //début du php / fin du html
//Cette requête récupère le libelle de la question précédente
if($_GET['id_q_suiv'] != 0)
{
	$questions_suivante = $bdd->query("SELECT * FROM questions
WHERE id_q =".$_GET['id_q_suiv']);
if($_GET['id_fin'] == 1){
//Instruction qui permet de récupérer id_fin qui indique si on sort de la boucle ou pas
//(0 on reste dans la boucle; 1 on sort de la boucle en exécutant la methode exit())
?> <!-- fin du php/ début du html -->
	<a <?php echo "href=Interface_utilisateur_FT.php?id_rep=".$id_rep."&confirm=1"; ?>  class="button button1">Votre problème est-il résolu ?</a></br>
	<a <?php echo "href='formulaire_mail.php?path=".$id_rep."'"; ?> class="button button1">Votre problème n'est pas résolu</a></br>
	<div class="centre">
		<a href="Interface_utilisateur_FT.php" class="button button2">Retourner au début ?</a></br>
	</div>
	<div class="centre">
		<form>
			<input type = "button" value = "Vous vous êtes trompé ?"  onclick = "history.back()" class="button button2">
		</form>
	</div>
<?php //début du php / fin du html
	exit();
  }
	while($resultatquest = $questions_suivante->fetch())
	{
?> <!-- fin du php/ début du html -->
		<a href="<?php echo "Reponse_FT.php?libelle=".$resultatquest['Libelle']."&id_pb=".$resultatquest['id_pb']."&id_q=".$resultatquest['id_q']."&id_rep=".$id_rep."".$resultatquest['id_q']."&confirm=1" ?>" class="button button1"><?php echo $resultatquest['Libelle']; ?></a></br>
<?php //début du php / fin du html
	}
	?> <!-- fin du php/ début du html -->
	<div class="centre">
		<form>
			<input type = "button" value = "Vous vous êtes trompé ?"  onclick = "history.back()" class="button button2">
		</form>
	</div>
	<?php //début du php / fin du html
}
else{
	$questions = $bdd->query("SELECT * FROM questions
		WHERE id_pb =".$_GET['id']);
	while($resultatquest = $questions->fetch())
//Cette boucle affiche les boutons suivant la table ou il va les chercher, ici il s'agit de la table questions
	{
?> <!-- fin du php/ début du html -->
	<a href="<?php echo "Reponse_FT.php?libelle=".$resultatquest['Libelle']."&id_pb=".$resultatquest['id_pb']."&id_q=".$resultatquest['id_q']."&id_rep=".$id_rep."".$resultatquest['id_q'] ?>" class="button button1"><?php echo $resultatquest['Libelle']; ?></a></br>
<?php //début du php / fin du html
	}
?> <!-- fin du php/ début du html -->
<div class="centre">
	<form>
		<input type = "button" value = "Vous vous êtes trompé ?"  onclick = "history.back()" class="button button2">
		<!-- Cette requête sert à faire apparaître un bouton qui servira à retourner en arrière d'une instruction -->
	</form>
</div>
<?php //début du php / fin du html
}
?> <!-- fin du php/ début du html -->
</body>
</html>
