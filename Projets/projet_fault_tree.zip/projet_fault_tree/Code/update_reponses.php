<html>
<head>
<link rel="stylesheet" href="./css/style.css" type="text/css">
<meta charset="utf-8">
</head>
<body>
<?php
//Page pour gérer les modifications des champs de la table reponses

echo "<form action='update.php?reponses_id=".$_GET['reponses_id']."' method='POST'>";
echo "<input type='int' name='reponses_id_q' placeholder='id_q'></input></br>";
echo "<input type='text' name='reponses_id_q_suiv' placeholder='id_q_suiv'></input></br>";
echo "<input type='text' name='reponses_id_fin' placeholder='id_fin'></input></br>";
echo "<input type='text' name='reponses_libelle' placeholder='Libelle'></input></br>";
echo "<input type='submit'></input>";
echo "</form>";
?>
<input type = "button" value = "Vous vous êtes trompé ?"  onclick = "history.back()" class="button button2">
</body>
</html>
