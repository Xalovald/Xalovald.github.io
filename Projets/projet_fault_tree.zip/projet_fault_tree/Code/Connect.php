<?php
$dsn = 'mysql:dbname=projet_fault_tree;host=127.0.0.1;charset=utf8';
$user = '';
$password = '';
$bdd = new PDO($dsn, $user, $password);
?>
