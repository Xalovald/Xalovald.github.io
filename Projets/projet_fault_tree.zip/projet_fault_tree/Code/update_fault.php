<html>
<head>
<link rel="stylesheet" href="./css/style.css" type="text/css">
<meta charset="utf-8">
</head>
<body>
<?php
//Page pour gérer les modifications des champs de la table fault

echo "<form action='update.php?fault_id=".$_GET['fault_id']."' method='POST'>";
echo "<input type='text' name='fault_libelle' placeholder='Libelle'></input></br>";
echo "<input type='int' name='fault_debut' placeholder='debut'></input></br>";
echo "<input type='submit'></input>";
echo "</form>";
?>
<input type = "button" value = "Vous vous êtes trompé ?"  onclick = "history.back()" class="button button2">
</body>
</html>
