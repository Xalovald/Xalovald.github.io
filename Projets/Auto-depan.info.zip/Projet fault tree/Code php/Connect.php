<?php //début du php / fin du html
//initialisation de la connexion à la bdd
$dsn = 'mysql:dbname=projet_fault_tree;host=127.0.0.1;charset=utf8';
$user = '';
$password = '';
$bdd = new PDO($dsn, $user, $password);
?> <!-- fin du php/ début du html -->
