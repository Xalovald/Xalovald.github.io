package com.example.gogmeteo.Model;

public class Forecast {
    private Main main;
    public Forecast(Main main)
    {
        this.main = main;
    }

    public Main getMain() {
        return main;
    }
}
