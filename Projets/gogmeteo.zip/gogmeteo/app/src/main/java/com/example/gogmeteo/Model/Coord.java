package com.example.gogmeteo.Model;

public class Coord {
    private float lat;
    private float lon;

    public Coord(float lat, float lon)
    {
        this.lat = lat;
        this.lon = lon;
    }

    public float get_lat() {
        return lat;
    }

    public float get_lon() {
        return lon;
    }
}
