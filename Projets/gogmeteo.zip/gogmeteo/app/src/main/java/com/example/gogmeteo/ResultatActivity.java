package com.example.gogmeteo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.gogmeteo.databinding.ActivityResultatBinding;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import java.io.IOException;
import java.sql.Time;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class ResultatActivity extends AppCompatActivity {
    private ActivityResultatBinding binding;
    private boolean _checking;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityResultatBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);

        Intent intent = getIntent();
        String _ville = intent.getStringExtra("ville");
        String _lat = intent.getStringExtra("latitude");
        String _lon = intent.getStringExtra("longitude");
        String _gagne = intent.getStringExtra("villeGagnante");
        String _username = intent.getStringExtra("username");
        String lePays = intent.getStringExtra("paysGagnant");



        Spinner spinner = (Spinner) findViewById(R.id.spinnerOuiNon);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.oui_non, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        if(_checking == true)
        {
            spinner.setSelection(1);
        }

        if (_ville.equals(_gagne)) {
            binding.tvBravoPerdu.setText("Bravo! vous avez gagné!");
            binding.tvbonneReponse.setText("La bonne ville était:  " + _gagne +"\n" + "Pays : " + lePays);
            binding.btnCalendrier.setEnabled(true);
            binding.btnCalendrier.setClickable(true);
            binding.btnCalendrier.setVisibility(View.VISIBLE);




        } else {
            binding.tvBravoPerdu.setText("Dommage! vous avez perdu!");
            binding.tvbonneReponse.setText("La bonne ville était:  " + _gagne +"\n" + "Pays : " + lePays);
        }
        binding.btnEmplacement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri gmmIntentUri = Uri.parse("geo:" + _lat + "," + _lon + "?z=10");
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);

            }
        });
        binding.btnCalendrier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Intent.ACTION_INSERT)
                        .setData(CalendarContract.Events.CONTENT_URI)
                        .putExtra(CalendarContract.Events.TITLE, "Vous avez gagné à GogMétéo")
                        .putExtra(CalendarContract.Events.DESCRIPTION, "Bravo vous avez gagné au jeu GogMétéo en ayant trouvé la bonne " +
                                "réponse : " + _gagne)
                        .putExtra(CalendarContract.Events.EVENT_LOCATION, "France")
                        .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, LocalDateTime.now())
                        .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, LocalDateTime.now());
                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                }
            }
        });
        binding.btnRejouer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String resultat = spinner.getSelectedItem().toString();
                if(resultat.equals("oui"))
                {
                    _checking = true;
                }
                Intent intent = new Intent(ResultatActivity.this, GogMeteoActivity.class);
                intent.putExtra("username", _username);
                intent.putExtra("checking", _checking);
                startActivity(intent);

            }
        });
    }
}