package com.example.gogmeteo;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.style.BackgroundColorSpan;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.example.gogmeteo.Adapter.RecyclerViewAdapter;
import com.example.gogmeteo.Interfaces.RecyclerViewClickListener;
import com.example.gogmeteo.Listeners.RecyclerTouchListener;
import com.example.gogmeteo.Model.Forecast;
import com.example.gogmeteo.Model.Item;
import com.example.gogmeteo.Model.Main;
import com.example.gogmeteo.Model.Forecasts;
import com.example.gogmeteo.databinding.ActivityGogMeteoBinding;
import com.example.gogmeteo.databinding.RecylerViewListMeteoBinding;
import com.google.android.gms.common.SignInButton;

import java.util.ArrayList;
import java.util.List;

public class GogMeteoActivity extends AppCompatActivity {
    private ActivityGogMeteoBinding binding;
    private String _username;
    private boolean _checking;
    private List<Integer> intList = new ArrayList<Integer>();
    private ArrayList<Item> _mesItems;
    private ArrayList<String> _listOrigin = new ArrayList<String>();
    private String uneLatitude;
    private String uneLongitude;
    private String uneVille;
    private String resultatPays;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setList();
        int randomIntVille = (int)(Math.random() * _listOrigin.size());

        String randomVille = this._listOrigin.get(randomIntVille);


        binding = ActivityGogMeteoBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);

        Intent intent = getIntent();
        _username = intent.getStringExtra("username");
        _checking = intent.getBooleanExtra("checking", false);

        addDatas();
        int randomInt = (int)(Math.random() * 5);
        uneVille = this._mesItems.get(randomInt).getVille();
        String widgetsExempleUrl = "https://api.openweathermap.org/data/2.5/forecast?q="+uneVille+"&units=metric&appid=6e8f5ccc29dd9745d7c314921a779068";
        final GsonRequest gsonRequest = new GsonRequest(widgetsExempleUrl, Forecasts.class, null, new
                Response.Listener<Forecasts>() {

                    @Override
                    public void onResponse(Forecasts forecasts) {
                        String resultat = "";

                        /*for(Forecast forecast : forecasts.getForecasts()){
                            resultat += forecast.toString();
                        }*/
                        resultat = String.valueOf(forecasts.getForecasts().get(0).getMain().getTemp());
                        resultatPays = String.valueOf(forecasts.getCity().getCountry());
                        if(_checking != true)
                        {
                            binding.tvTemp.setText("La température est : " + resultat + " C°");
                        }
                        else{
                            binding.tvTemp.setText("La température est : " + resultat + " C°\n"+
                            "Le pays est : "+resultatPays);
                        }
                        String ville = String.valueOf(forecasts.getCity().getName());
                        uneLatitude = String.valueOf(forecasts.getCity().getCoord().get_lat());
                        Log.v("lat",String.valueOf(forecasts.getCity().getCoord().get_lat()));
                        uneLongitude = String.valueOf(forecasts.getCity().getCoord().get_lon());
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                if (volleyError != null) Log.e("MainActivity", volleyError.getMessage());
            }
        });

        VolleyHelper.getInstance(getApplicationContext()).addToRequestQueue(gsonRequest);



        binding.rvMeteo.setHasFixedSize(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext(),LinearLayoutManager.VERTICAL,false);
        binding.rvMeteo.setLayoutManager(layoutManager);
        binding.rvMeteo.setFocusable(false);

        RecyclerViewAdapter adapter = new RecyclerViewAdapter(_mesItems);

        binding.rvMeteo.setAdapter(adapter);
        binding.rvMeteo.addOnItemTouchListener(new RecyclerTouchListener(this, binding.rvMeteo, new RecyclerViewClickListener() {
            @Override
            public void onClick(View view, int position) {
                Intent intent = new Intent(GogMeteoActivity.this, ResultatActivity.class);
                intent.putExtra("ville",getVille(position));
                setIntent(intent);
                startActivity(intent);
            }
        }));
        binding.tvRegleAndUsername.setText("Bonjour "+_username+", le but de ce mini-jeu est de retrouver la bonne ville parmi les cinq ci-dessus en ayant pour seul indice" +
                " la température affichée au dessus de ce texte.\n Bonne chance!");



    }
    public String getVille(int unInt)
    {
        String ville = _mesItems.get(unInt).getVille();
        return ville;
    }
    public void addDatas()
    {
        _mesItems = new ArrayList<Item>();
        for (int i=0;i<5;i++) {
            int randomize = (int)(Math.random() * _listOrigin.size());
            intList.add(randomize);
            Item monItem = new Item(_listOrigin.get(randomize));
            _listOrigin.remove(randomize);
            _mesItems.add(monItem);
        }
    }
    public void setIntent(Intent unIntent)
    {
        unIntent.putExtra("latitude",uneLatitude);
        unIntent.putExtra("longitude",uneLongitude);
        unIntent.putExtra("villeGagnante",uneVille);
        unIntent.putExtra("username",_username);
        unIntent.putExtra("paysGagnant", resultatPays);
    }
    public void setList()
    {
        _listOrigin.add("Moscow");
        _listOrigin.add("Kaboul");
        _listOrigin.add("Tirana");
        _listOrigin.add("Rabat");
        _listOrigin.add("Alger");
        _listOrigin.add("Paris");
        _listOrigin.add("Tokyo");
        _listOrigin.add("Andorre");
        _listOrigin.add("Bakou");
        _listOrigin.add("Nassau");
        _listOrigin.add("Sydney");
        _listOrigin.add("Luanda");
        _listOrigin.add("Manama");
        _listOrigin.add("Taiwan");
        _listOrigin.add("Dacca");
        _listOrigin.add("Bridgetown");
        _listOrigin.add("Buenos aires");
        _listOrigin.add("Gaborone");
        _listOrigin.add("Sofia");
        _listOrigin.add("Ouagadougou");
        _listOrigin.add("Gitega");
        _listOrigin.add("Belmopan");
        _listOrigin.add("Porto-novo");
        _listOrigin.add("Minsk");
        _listOrigin.add("Dunkerque");
        _listOrigin.add("Bruxelles");
        _listOrigin.add("Thimphou");
        _listOrigin.add("Sucre");
        _listOrigin.add("Sarajevo");
        _listOrigin.add("Annecy");
        _listOrigin.add("Erevan");
        _listOrigin.add("Canberra");
        _listOrigin.add("Chambery");
        _listOrigin.add("Lyon");
        _listOrigin.add("Tour");
        _listOrigin.add("vienne");
        _listOrigin.add("Lille");
        _listOrigin.add("New york");
        _listOrigin.add("Marseille");
        _listOrigin.add("Svalbard");
        _listOrigin.add("Sandwich");
        _listOrigin.add("New Delhi");
        _listOrigin.add("Madagascar");
        _listOrigin.add("Cayenne");
        _listOrigin.add("Hong Kong");
        _listOrigin.add("Toronto");
        _listOrigin.add("Brasilia");
    }
    public ArrayList<String> getList()
    {
        return _listOrigin;
    }
}