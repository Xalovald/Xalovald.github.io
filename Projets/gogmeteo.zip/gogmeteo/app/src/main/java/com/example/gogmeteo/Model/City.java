package com.example.gogmeteo.Model;

public class City {
    private String name;
    private Coord coord;
    private String country;
    public City(String unNom, float lat, float lon, String country)
    {
        this.name = unNom;
        this.country = country;
        this.coord = new Coord(lat,lon);
    }

    public String getName() {
        return name;
    }

    public Coord getCoord() {
        return coord;
    }

    public String getCountry() {
        return country;
    }
}
