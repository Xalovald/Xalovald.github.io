package com.example.gogmeteo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.gogmeteo.databinding.ActivityMainBinding;


public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    private boolean _facile;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);

        binding.BtnJouer.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if(getUserName().equals("") | getUserName().contains(" ")){
                    binding.textErreur.setText("Vous devez rentrer un nom d'utilisateur valide pour pouvoir jouer!");
                    binding.editTextNom.setText("");

                }
                else {
                    binding.textErreur.setText("");
                    if(binding.checkBxEasy.isChecked())
                    {
                        _facile = true;
                    }
                    else {
                        _facile = false;
                    }
                    Intent intent = new Intent(MainActivity.this, GogMeteoActivity.class);
                    intent.putExtra("username", getUserName());
                    intent.putExtra("checking", _facile);
                    binding.editTextNom.setText("");
                    startActivity(intent);
                }

            }
        });
    }

    private String getUserName()
    {
       return binding.editTextNom.getText().toString();
    }


}