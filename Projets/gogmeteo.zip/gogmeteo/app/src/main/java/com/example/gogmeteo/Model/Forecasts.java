package com.example.gogmeteo.Model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Forecasts implements Serializable {

    private List<Forecast> list = new ArrayList<Forecast>();
    private City city;
    public Forecasts(List<Forecast> forecasts, String city,float lat, float lon, String country){
        this.list = forecasts;
        this.city = new City(city,lat,lon,country);

    }

    public List<Forecast> getForecasts() {
        return list;
    }
    public City getCity() {
        return city;
    }
}
