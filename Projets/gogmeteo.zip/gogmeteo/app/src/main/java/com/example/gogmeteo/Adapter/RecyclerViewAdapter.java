package com.example.gogmeteo.Adapter;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.gogmeteo.GogMeteoActivity;
import com.example.gogmeteo.MainActivity;
import com.example.gogmeteo.Model.Item;
import com.example.gogmeteo.R;
import com.example.gogmeteo.ResultatActivity;

import java.util.List;

public class RecyclerViewAdapter  extends RecyclerView.Adapter<RecyclerViewAdapter.RecyclerViewHolder> {
    private List<Item> dataModelList;

    public RecyclerViewAdapter(List<Item> dataModelList)
    {
        this.dataModelList = dataModelList;
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerViewHolder viewHolder;
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyler_view_list_meteo, parent, false);
        viewHolder = new RecyclerViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, int position) {
        holder.tvlistItem.setText(String.valueOf(dataModelList.get(position).getVille()));

    }

    @Override
    public int getItemCount() {
        return dataModelList.size();
    }

    public class RecyclerViewHolder extends RecyclerView.ViewHolder {
        TextView tvlistItem;
        public RecyclerViewHolder(@NonNull View itemView) {
            super(itemView);
            tvlistItem = itemView.findViewById(R.id.tvListeItem);

        }


    }
}
