package com.example.gogmeteo.Model;

public class Item {
    private String _ville;
    private int _id;
    public Item(String uneVille)
    {
        this._ville = uneVille;
    }
    public String getVille()
    {
        return this._ville;
    }
}
