package com.example.gogmeteo.Model;

import java.io.Serializable;
import java.util.List;


public class Main implements Serializable  {

    private float temp;
    private float temp_min;
    private float temp_max;

    public Main(float temp, float temp_min, float temp_max, String name){
        this.temp = temp;
        this.temp_min = temp_min;
        this.temp_max = temp_max;
    }

    public float getTemp() {
        return temp;
    }
}
